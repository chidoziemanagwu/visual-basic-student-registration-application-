﻿Public Class Form5

    Private Sub gb_Click(sender As Object, e As EventArgs) Handles gb.Click
        Me.Hide()
        Form2.Show()

    End Sub

    Private Sub loginbtn_Click(sender As Object, e As EventArgs) Handles loginbtn.Click
        Dim username, password As String
        Dim feedback, feedbacksec As Integer
        username = "ayo"
        password = "ayo123"

        If uname.Text = username And pword.Text = password Then
            feedback = MsgBox("sign in successful", vbOKCancel, "Login Attempt")
            If feedback = 1 Then
                uname.Visible = False
                pword.Visible = False
                Label1.Visible = False
                
                loginbtn.Visible = False
                showpword.Visible = False
                hidepword.Visible = False
                Me.Height = 890
            ElseIf feedback = 2 Then
                MsgBox("Ypu have chosen to end the program")
            End If
        ElseIf Not (uname.Text = username) Or Not (pword.Text = password) Then
            feedbacksec = MsgBox("You didn't usde the right keys", vbOKCancel, "login attempt")
        End If
    End Sub


    Private Sub showpword_Click(sender As Object, e As EventArgs) Handles showpword.Click
        pword.PasswordChar = ""
        showpword.Visible = False
        hidepword.Visible = True
    End Sub

    Private Sub hidepword_Click(sender As Object, e As EventArgs) Handles hidepword.Click
        pword.PasswordChar = "*"
        hidepword.Visible = False
        showpword.Visible = True
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MsgBox("This form makes use of AND,OR,NOT  logical operators to check your login details")
        Me.Height = 300
    End Sub

    Private Sub changebg_Click(sender As Object, e As EventArgs) Handles changebg.Click
        If first.Text > 0.9 Or second.Text > 0.9 Or third.Text > 0.9 Then
            MsgBox("You didn't read the guide")
        Else
            Dim r, g, b As Double

            r = Int(Val(first.Text) * 256)
            g = Int(Val(second.Text) * 256)
            b = Int(Val(third.Text) * 256)
            Me.BackColor = Color.FromArgb(r, g, b)
        End If
    End Sub

End Class