﻿Public Class Form4

    Private Sub click_Click(sender As Object, e As EventArgs) Handles click.Click
        Dim x As Integer
        x = Val(text1.Text)
        mult(x)
    End Sub
    Public Sub mult(num As Integer)
        Dim i, ans As Integer
        Do
            ans = num * i
            listv.Items.Add(ans)
            i = i + 1
        Loop Until i > 100
        msg()
    End Sub
    Public Sub msg()
        Dim disp As Integer
        disp = MsgBox("This is a sub routine inside another sub routine, it triggers once the loop is executed completely", vbOKCancel, "Two layer sub routine")
    End Sub

    Private Sub gb_Click(sender As Object, e As EventArgs) Handles gb.Click
        Me.Hide()
        Form2.Show()

    End Sub
End Class