﻿Public Class Form7

    Private Sub gb_Click(sender As Object, e As EventArgs) Handles gb.Click
        Me.Hide()
        Form2.Show()
    End Sub

    Private Sub calcarea_Click(sender As Object, e As EventArgs) Handles calcarea.Click
        Dim x As Integer
        x = Val(radiusbox.Text)
        area(x)
    End Sub
    Public Sub area(num As Integer)
        Dim ans As Integer
        Const pi As Double = 3.14
        ans = (num ^ 2) * pi
        abox.Text = "Area = " & ans
    End Sub
End Class