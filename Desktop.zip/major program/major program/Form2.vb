﻿Public Class Form2

    Private Sub lgoutbtn_Click(sender As Object, e As EventArgs)
        Me.Hide()
        Form1.Show()

    End Sub

    Private Sub extbtn_Click(sender As Object, e As EventArgs) Handles extbtn.Click
        End
    End Sub

    Private Sub uds_Click(sender As Object, e As EventArgs) Handles uds.Click
        Me.Hide()
        Form4.Show()

    End Sub

    Private Sub andbtn_Click(sender As Object, e As EventArgs) Handles andbtn.Click
        Me.Hide()
        Form5.Show()

    End Sub

    Private Sub udf_Click(sender As Object, e As EventArgs) Handles udf.Click
        Me.Hide()
        Form6.Show()

    End Sub

    Private Sub dbg_Click(sender As Object, e As EventArgs) Handles dbg.Click
        Me.Hide()
        Form7.Show()
    End Sub

    Private Sub pploop_Click(sender As Object, e As EventArgs) Handles pploop.Click
        Me.Hide()
        Form8.Show()

    End Sub
End Class