﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.extbtn = New System.Windows.Forms.Button()
        Me.target1 = New System.Windows.Forms.DateTimePicker()
        Me.started1 = New System.Windows.Forms.DateTimePicker()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.updtbtn = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.pword2 = New System.Windows.Forms.TextBox()
        Me.uname2 = New System.Windows.Forms.TextBox()
        Me.sdesc1 = New System.Windows.Forms.TextBox()
        Me.labname1 = New System.Windows.Forms.TextBox()
        Me.slname1 = New System.Windows.Forms.TextBox()
        Me.sfname1 = New System.Windows.Forms.TextBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.pword3 = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.dltbtn = New System.Windows.Forms.Button()
        Me.ext = New System.Windows.Forms.Button()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.rdct = New System.Windows.Forms.Button()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Location = New System.Drawing.Point(12, 12)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(593, 596)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.extbtn)
        Me.TabPage1.Controls.Add(Me.target1)
        Me.TabPage1.Controls.Add(Me.started1)
        Me.TabPage1.Controls.Add(Me.Label9)
        Me.TabPage1.Controls.Add(Me.Label8)
        Me.TabPage1.Controls.Add(Me.updtbtn)
        Me.TabPage1.Controls.Add(Me.Label7)
        Me.TabPage1.Controls.Add(Me.Label6)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.pword2)
        Me.TabPage1.Controls.Add(Me.uname2)
        Me.TabPage1.Controls.Add(Me.sdesc1)
        Me.TabPage1.Controls.Add(Me.labname1)
        Me.TabPage1.Controls.Add(Me.slname1)
        Me.TabPage1.Controls.Add(Me.sfname1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(585, 570)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Edit students Details"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'extbtn
        '
        Me.extbtn.BackColor = System.Drawing.Color.Red
        Me.extbtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.extbtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.extbtn.Location = New System.Drawing.Point(320, 523)
        Me.extbtn.Name = "extbtn"
        Me.extbtn.Size = New System.Drawing.Size(139, 35)
        Me.extbtn.TabIndex = 36
        Me.extbtn.Text = "Exit"
        Me.extbtn.UseVisualStyleBackColor = False
        '
        'target1
        '
        Me.target1.Location = New System.Drawing.Point(320, 301)
        Me.target1.Name = "target1"
        Me.target1.Size = New System.Drawing.Size(200, 20)
        Me.target1.TabIndex = 35
        '
        'started1
        '
        Me.started1.Location = New System.Drawing.Point(28, 301)
        Me.started1.Name = "started1"
        Me.started1.Size = New System.Drawing.Size(196, 20)
        Me.started1.TabIndex = 34
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(80, 285)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(67, 13)
        Me.Label9.TabIndex = 33
        Me.Label9.Text = "Date Started"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(358, 285)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(116, 13)
        Me.Label8.TabIndex = 32
        Me.Label8.Text = "Target completion date"
        '
        'updtbtn
        '
        Me.updtbtn.BackColor = System.Drawing.Color.PaleGreen
        Me.updtbtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.updtbtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.updtbtn.Location = New System.Drawing.Point(147, 523)
        Me.updtbtn.Name = "updtbtn"
        Me.updtbtn.Size = New System.Drawing.Size(139, 35)
        Me.updtbtn.TabIndex = 31
        Me.updtbtn.Text = "Update"
        Me.updtbtn.UseVisualStyleBackColor = False
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Coral
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label7.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Label7.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(43, 359)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(513, 57)
        Me.Label7.TabIndex = 30
        Me.Label7.Text = "USER LOGIN DETAILS"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(447, 488)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(53, 13)
        Me.Label6.TabIndex = 29
        Me.Label6.Text = "Password"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(92, 488)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(55, 13)
        Me.Label5.TabIndex = 28
        Me.Label5.Text = "Username"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(61, 182)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(86, 13)
        Me.Label4.TabIndex = 27
        Me.Label4.Text = "Short description"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(61, 126)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(103, 13)
        Me.Label3.TabIndex = 26
        Me.Label3.Text = "Vb lab/project name"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(61, 66)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(98, 13)
        Me.Label2.TabIndex = 25
        Me.Label2.Text = "Student Last Name"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(61, 10)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(97, 13)
        Me.Label1.TabIndex = 24
        Me.Label1.Text = "Student First Name"
        '
        'pword2
        '
        Me.pword2.Location = New System.Drawing.Point(385, 452)
        Me.pword2.MaxLength = 10
        Me.pword2.Name = "pword2"
        Me.pword2.Size = New System.Drawing.Size(171, 20)
        Me.pword2.TabIndex = 23
        '
        'uname2
        '
        Me.uname2.Location = New System.Drawing.Point(43, 452)
        Me.uname2.MaxLength = 30
        Me.uname2.Name = "uname2"
        Me.uname2.Size = New System.Drawing.Size(171, 20)
        Me.uname2.TabIndex = 22
        '
        'sdesc1
        '
        Me.sdesc1.Location = New System.Drawing.Point(303, 179)
        Me.sdesc1.MaxLength = 60
        Me.sdesc1.Multiline = True
        Me.sdesc1.Name = "sdesc1"
        Me.sdesc1.Size = New System.Drawing.Size(171, 85)
        Me.sdesc1.TabIndex = 21
        '
        'labname1
        '
        Me.labname1.Location = New System.Drawing.Point(303, 119)
        Me.labname1.MaxLength = 50
        Me.labname1.Name = "labname1"
        Me.labname1.Size = New System.Drawing.Size(171, 20)
        Me.labname1.TabIndex = 20
        '
        'slname1
        '
        Me.slname1.Location = New System.Drawing.Point(303, 59)
        Me.slname1.MaxLength = 40
        Me.slname1.Name = "slname1"
        Me.slname1.Size = New System.Drawing.Size(171, 20)
        Me.slname1.TabIndex = 19
        '
        'sfname1
        '
        Me.sfname1.Location = New System.Drawing.Point(303, 10)
        Me.sfname1.MaxLength = 30
        Me.sfname1.Name = "sfname1"
        Me.sfname1.Size = New System.Drawing.Size(171, 20)
        Me.sfname1.TabIndex = 18
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.pword3)
        Me.TabPage2.Controls.Add(Me.Label10)
        Me.TabPage2.Controls.Add(Me.dltbtn)
        Me.TabPage2.Controls.Add(Me.ext)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(585, 570)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Delete Student Details"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'pword3
        '
        Me.pword3.Location = New System.Drawing.Point(252, 63)
        Me.pword3.Name = "pword3"
        Me.pword3.Size = New System.Drawing.Size(226, 20)
        Me.pword3.TabIndex = 42
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(90, 61)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(86, 20)
        Me.Label10.TabIndex = 41
        Me.Label10.Text = "Password"
        '
        'dltbtn
        '
        Me.dltbtn.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.dltbtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.dltbtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dltbtn.Location = New System.Drawing.Point(69, 268)
        Me.dltbtn.Name = "dltbtn"
        Me.dltbtn.Size = New System.Drawing.Size(139, 35)
        Me.dltbtn.TabIndex = 40
        Me.dltbtn.Text = "Delete Record"
        Me.dltbtn.UseVisualStyleBackColor = False
        '
        'ext
        '
        Me.ext.BackColor = System.Drawing.Color.Red
        Me.ext.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.ext.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ext.Location = New System.Drawing.Point(372, 268)
        Me.ext.Name = "ext"
        Me.ext.Size = New System.Drawing.Size(139, 35)
        Me.ext.TabIndex = 39
        Me.ext.Text = "Exit"
        Me.ext.UseVisualStyleBackColor = False
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.rdct)
        Me.TabPage3.Controls.Add(Me.Label11)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(585, 570)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Go to programs"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.Color.Goldenrod
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(30, 46)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(532, 74)
        Me.Label11.TabIndex = 0
        Me.Label11.Text = "Don't miss out on the fun, click the button below to go to  the programs to also " & _
    "see how they work"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'rdct
        '
        Me.rdct.BackColor = System.Drawing.Color.PaleGreen
        Me.rdct.Location = New System.Drawing.Point(195, 172)
        Me.rdct.Name = "rdct"
        Me.rdct.Size = New System.Drawing.Size(213, 74)
        Me.rdct.TabIndex = 1
        Me.rdct.Text = "Redirect"
        Me.rdct.UseVisualStyleBackColor = False
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(617, 604)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "Form3"
        Me.Text = "Form3"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents target1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents started1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents updtbtn As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents pword2 As System.Windows.Forms.TextBox
    Friend WithEvents uname2 As System.Windows.Forms.TextBox
    Friend WithEvents sdesc1 As System.Windows.Forms.TextBox
    Friend WithEvents labname1 As System.Windows.Forms.TextBox
    Friend WithEvents slname1 As System.Windows.Forms.TextBox
    Friend WithEvents sfname1 As System.Windows.Forms.TextBox
    Friend WithEvents extbtn As System.Windows.Forms.Button
    Friend WithEvents dltbtn As System.Windows.Forms.Button
    Friend WithEvents ext As System.Windows.Forms.Button
    Friend WithEvents pword3 As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents rdct As System.Windows.Forms.Button
    Friend WithEvents Label11 As System.Windows.Forms.Label
End Class
