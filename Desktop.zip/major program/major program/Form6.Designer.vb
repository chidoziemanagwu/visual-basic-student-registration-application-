﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form6
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ansbtn = New System.Windows.Forms.Button()
        Me.ansbox = New System.Windows.Forms.Label()
        Me.secondval = New System.Windows.Forms.TextBox()
        Me.nthval = New System.Windows.Forms.TextBox()
        Me.firstval = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.proceedbtn = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.gb = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'ansbtn
        '
        Me.ansbtn.Location = New System.Drawing.Point(77, 411)
        Me.ansbtn.Name = "ansbtn"
        Me.ansbtn.Size = New System.Drawing.Size(189, 34)
        Me.ansbtn.TabIndex = 19
        Me.ansbtn.Text = "Get the value"
        Me.ansbtn.UseVisualStyleBackColor = True
        '
        'ansbox
        '
        Me.ansbox.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.ansbox.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ansbox.Location = New System.Drawing.Point(43, 339)
        Me.ansbox.Name = "ansbox"
        Me.ansbox.Size = New System.Drawing.Size(450, 54)
        Me.ansbox.TabIndex = 18
        Me.ansbox.Text = "Your answer will appear here"
        Me.ansbox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'secondval
        '
        Me.secondval.Location = New System.Drawing.Point(295, 236)
        Me.secondval.Name = "secondval"
        Me.secondval.Size = New System.Drawing.Size(107, 20)
        Me.secondval.TabIndex = 17
        '
        'nthval
        '
        Me.nthval.Location = New System.Drawing.Point(295, 297)
        Me.nthval.Name = "nthval"
        Me.nthval.Size = New System.Drawing.Size(107, 20)
        Me.nthval.TabIndex = 16
        '
        'firstval
        '
        Me.firstval.Location = New System.Drawing.Point(295, 177)
        Me.firstval.Name = "firstval"
        Me.firstval.Size = New System.Drawing.Size(107, 20)
        Me.firstval.TabIndex = 15
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(74, 304)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(54, 13)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "Nth Value"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(74, 243)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(74, 13)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "Second Value"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(74, 175)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(56, 13)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "First Value"
        '
        'proceedbtn
        '
        Me.proceedbtn.Location = New System.Drawing.Point(172, 93)
        Me.proceedbtn.Name = "proceedbtn"
        Me.proceedbtn.Size = New System.Drawing.Size(189, 34)
        Me.proceedbtn.TabIndex = 11
        Me.proceedbtn.Text = "Proceed"
        Me.proceedbtn.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(38, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(455, 68)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "This section makes use of user defined functions to perform arithmetic progressio" & _
    "n. You are to enter the first two numbers and the nth value you are looking forr" & _
    " in the sequence."
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'gb
        '
        Me.gb.Location = New System.Drawing.Point(295, 411)
        Me.gb.Name = "gb"
        Me.gb.Size = New System.Drawing.Size(189, 34)
        Me.gb.TabIndex = 20
        Me.gb.Text = "Go back"
        Me.gb.UseVisualStyleBackColor = True
        '
        'Form6
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(531, 457)
        Me.Controls.Add(Me.gb)
        Me.Controls.Add(Me.ansbtn)
        Me.Controls.Add(Me.ansbox)
        Me.Controls.Add(Me.secondval)
        Me.Controls.Add(Me.nthval)
        Me.Controls.Add(Me.firstval)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.proceedbtn)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form6"
        Me.Text = "Form6"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ansbtn As System.Windows.Forms.Button
    Friend WithEvents ansbox As System.Windows.Forms.Label
    Friend WithEvents secondval As System.Windows.Forms.TextBox
    Friend WithEvents nthval As System.Windows.Forms.TextBox
    Friend WithEvents firstval As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents proceedbtn As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents gb As System.Windows.Forms.Button
End Class
