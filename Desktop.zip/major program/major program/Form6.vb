﻿Public Class Form6

    Private Sub gb_Click(sender As Object, e As EventArgs) Handles gb.Click
        Me.Hide()
        Form2.Show()

    End Sub
    Dim d As Integer
    Private Sub proceedbtn_Click(sender As Object, e As EventArgs) Handles proceedbtn.Click
        proceedbtn.Visible = False
        Label1.Visible = False
    End Sub

    Private Sub ansbtn_Click(sender As Object, e As EventArgs) Handles ansbtn.Click
        Dim first, second, nth, ans As Integer
        first = Val(firstval.Text)
        second = Val(secondval.Text)
        nth = Val(nthval.Text)
        ans = aprog(first, second, nth)
        ansbox.Text = "Value in position " & nth & " is " & ans
    End Sub
    Public Function aprog(one As Integer, two As Integer, three As Integer)
        d = two - one
        aprog = one + (three - 1) * d
    End Function
End Class