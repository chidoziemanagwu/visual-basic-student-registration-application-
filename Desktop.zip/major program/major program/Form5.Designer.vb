﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form5
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.changebg = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.third = New System.Windows.Forms.TextBox()
        Me.second = New System.Windows.Forms.TextBox()
        Me.first = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.hidepword = New System.Windows.Forms.Button()
        Me.showpword = New System.Windows.Forms.Button()
        Me.loginbtn = New System.Windows.Forms.Button()
        Me.pword = New System.Windows.Forms.TextBox()
        Me.uname = New System.Windows.Forms.TextBox()
        Me.gb = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'changebg
        '
        Me.changebg.Location = New System.Drawing.Point(183, 526)
        Me.changebg.Name = "changebg"
        Me.changebg.Size = New System.Drawing.Size(144, 39)
        Me.changebg.TabIndex = 26
        Me.changebg.Text = "Change Background"
        Me.changebg.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.Cursor = System.Windows.Forms.Cursors.SizeNS
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(78, 472)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(611, 51)
        Me.Label5.TabIndex = 25
        Me.Label5.Text = "This section makes use of the OR operator, in each box you  are expected to enter" & _
    " a value between 0 and 0.9 and once you click change background color it  will c" & _
    "hannge the background color."
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'third
        '
        Me.third.Location = New System.Drawing.Point(430, 395)
        Me.third.Multiline = True
        Me.third.Name = "third"
        Me.third.Size = New System.Drawing.Size(184, 43)
        Me.third.TabIndex = 24
        '
        'second
        '
        Me.second.Location = New System.Drawing.Point(430, 315)
        Me.second.Multiline = True
        Me.second.Name = "second"
        Me.second.Size = New System.Drawing.Size(184, 43)
        Me.second.TabIndex = 23
        '
        'first
        '
        Me.first.Location = New System.Drawing.Point(430, 228)
        Me.first.Multiline = True
        Me.first.Name = "first"
        Me.first.Size = New System.Drawing.Size(184, 43)
        Me.first.TabIndex = 22
        '
        'Label4
        '
        Me.Label4.Cursor = System.Windows.Forms.Cursors.SizeNS
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(95, 408)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(65, 30)
        Me.Label4.TabIndex = 21
        Me.Label4.Text = "B"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label3
        '
        Me.Label3.Cursor = System.Windows.Forms.Cursors.SizeNS
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(95, 328)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 30)
        Me.Label3.TabIndex = 20
        Me.Label3.Text = "G"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label2
        '
        Me.Label2.Cursor = System.Windows.Forms.Cursors.SizeNS
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(95, 241)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(65, 30)
        Me.Label2.TabIndex = 19
        Me.Label2.Text = "R"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'hidepword
        '
        Me.hidepword.Location = New System.Drawing.Point(587, 183)
        Me.hidepword.Name = "hidepword"
        Me.hidepword.Size = New System.Drawing.Size(144, 39)
        Me.hidepword.TabIndex = 18
        Me.hidepword.Text = "Hide Password"
        Me.hidepword.UseVisualStyleBackColor = True
        Me.hidepword.Visible = False
        '
        'showpword
        '
        Me.showpword.Location = New System.Drawing.Point(324, 183)
        Me.showpword.Name = "showpword"
        Me.showpword.Size = New System.Drawing.Size(144, 39)
        Me.showpword.TabIndex = 17
        Me.showpword.Text = "Show Password"
        Me.showpword.UseVisualStyleBackColor = True
        '
        'loginbtn
        '
        Me.loginbtn.Location = New System.Drawing.Point(60, 183)
        Me.loginbtn.Name = "loginbtn"
        Me.loginbtn.Size = New System.Drawing.Size(144, 39)
        Me.loginbtn.TabIndex = 16
        Me.loginbtn.Text = "Login"
        Me.loginbtn.UseVisualStyleBackColor = True
        '
        'pword
        '
        Me.pword.Location = New System.Drawing.Point(518, 134)
        Me.pword.Multiline = True
        Me.pword.Name = "pword"
        Me.pword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.pword.Size = New System.Drawing.Size(184, 43)
        Me.pword.TabIndex = 15
        '
        'uname
        '
        Me.uname.Location = New System.Drawing.Point(48, 134)
        Me.uname.Multiline = True
        Me.uname.Name = "uname"
        Me.uname.Size = New System.Drawing.Size(184, 43)
        Me.uname.TabIndex = 14
        '
        'gb
        '
        Me.gb.Location = New System.Drawing.Point(430, 526)
        Me.gb.Name = "gb"
        Me.gb.Size = New System.Drawing.Size(144, 39)
        Me.gb.TabIndex = 27
        Me.gb.Text = "Go Back"
        Me.gb.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Cursor = System.Windows.Forms.Cursors.SizeNS
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(44, 35)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(611, 51)
        Me.Label1.TabIndex = 28
        Me.Label1.Text = "The login part demonstrates the AND logical operator, username ""ayo"" password ""ay" & _
    "o123"" for fun just try entering wrong values."
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Form5
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(743, 597)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.gb)
        Me.Controls.Add(Me.changebg)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.third)
        Me.Controls.Add(Me.second)
        Me.Controls.Add(Me.first)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.hidepword)
        Me.Controls.Add(Me.showpword)
        Me.Controls.Add(Me.loginbtn)
        Me.Controls.Add(Me.pword)
        Me.Controls.Add(Me.uname)
        Me.Name = "Form5"
        Me.Text = "Form5"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents changebg As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents third As System.Windows.Forms.TextBox
    Friend WithEvents second As System.Windows.Forms.TextBox
    Friend WithEvents first As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents hidepword As System.Windows.Forms.Button
    Friend WithEvents showpword As System.Windows.Forms.Button
    Friend WithEvents loginbtn As System.Windows.Forms.Button
    Friend WithEvents pword As System.Windows.Forms.TextBox
    Friend WithEvents uname As System.Windows.Forms.TextBox
    Friend WithEvents gb As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
