﻿Imports System.Data.OleDb
Public Class Form3
    Dim provider As String
    Dim datafile As String
    Dim connstring As String
    Dim myconnection As OleDbConnection = New OleDbConnection
    Private Sub updtbtn_Click(sender As Object, e As EventArgs) Handles updtbtn.Click
        provider = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source ="
        datafile = "C:\Users\hp pc\Documents\Visual Studio 2013\Projects\major program\major program\Studentdb.accdb"
        connstring = provider & datafile
        myconnection.ConnectionString = connstring

        myconnection.Open()
        Dim str As String
        str = "update [studenttable] set [studentFirstName] = '" & sfname1.Text & "' , [studentLastName] = '" & slname1.Text & "', [vbLabName] = '" & labname1.Text & "', [shortDescription] = '" & sdesc1.Text & "', [datestarted] = '" & started1.Value & "', [targetdate] = '" & target1.Value & "', [username] = '" & uname2.Text & "' where [password] = '" & pword2.Text & "'"
        Dim cmd As OleDbCommand = New OleDbCommand(str, myconnection)
        Try
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            myconnection.Close()
            MsgBox("Update Successful, " & sfname1.Text, MessageBoxIcon.Information, "Update Form")
            sfname1.Clear()
            slname1.Clear()
            labname1.Clear()
            sdesc1.Clear()
            uname2.Clear()
            pword2.Clear()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub extbtn_Click(sender As Object, e As EventArgs) Handles extbtn.Click
        End

    End Sub

    Private Sub ext_Click(sender As Object, e As EventArgs) Handles ext.Click
        End

    End Sub

    
    Private Sub dltbtn_Click(sender As Object, e As EventArgs) Handles dltbtn.Click
        Dim oktodel As MsgBoxResult = MsgBox("Are you sure you want to perform this action, it is irreversible...", MessageBoxIcon.Warning, MsgBoxStyle.OkCancel)
        If oktodel = MsgBoxResult.Ok Then
            provider = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source ="
            datafile = "C:\Users\hp pc\Documents\Visual Studio 2013\Projects\major program\major program\Studentdb.accdb"
            connstring = provider & datafile
            myconnection.ConnectionString = connstring

            myconnection.Open()
            Dim str As String
            str = "Delete from studenttable Where password = '" & pword3.Text & "'"
            Dim cmd As OleDbCommand = New OleDbCommand(str, myconnection)
            Try
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                myconnection.Close()
                MsgBox("Delete Successful, " & sfname1.Text, MessageBoxIcon.Information, "Delete Form")
                pword3.Clear()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        ElseIf oktodel = MsgBoxResult.Cancel Then
        End If
    End Sub

    Private Sub rdct_Click(sender As Object, e As EventArgs) Handles rdct.Click
        Me.Hide()
        Form2.Show()

    End Sub
End Class