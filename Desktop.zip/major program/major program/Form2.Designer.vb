﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.welcome = New System.Windows.Forms.Label()
        Me.andbtn = New System.Windows.Forms.Button()
        Me.pploop = New System.Windows.Forms.Button()
        Me.udf = New System.Windows.Forms.Button()
        Me.uds = New System.Windows.Forms.Button()
        Me.dbg = New System.Windows.Forms.Button()
        Me.extbtn = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'welcome
        '
        Me.welcome.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.welcome.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.welcome.Location = New System.Drawing.Point(12, 26)
        Me.welcome.Name = "welcome"
        Me.welcome.Size = New System.Drawing.Size(640, 71)
        Me.welcome.TabIndex = 0
        Me.welcome.Text = "WELCOME, Click on any of the programs below to see run it and see how it works"
        Me.welcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'andbtn
        '
        Me.andbtn.Location = New System.Drawing.Point(12, 145)
        Me.andbtn.Name = "andbtn"
        Me.andbtn.Size = New System.Drawing.Size(161, 73)
        Me.andbtn.TabIndex = 1
        Me.andbtn.Text = "AND,OR,NOT Operators"
        Me.andbtn.UseVisualStyleBackColor = True
        '
        'pploop
        '
        Me.pploop.Location = New System.Drawing.Point(491, 145)
        Me.pploop.Name = "pploop"
        Me.pploop.Size = New System.Drawing.Size(161, 73)
        Me.pploop.TabIndex = 2
        Me.pploop.Text = "Post and pre condition Loop"
        Me.pploop.UseVisualStyleBackColor = True
        '
        'udf
        '
        Me.udf.Location = New System.Drawing.Point(256, 261)
        Me.udf.Name = "udf"
        Me.udf.Size = New System.Drawing.Size(161, 73)
        Me.udf.TabIndex = 3
        Me.udf.Text = "User defined function"
        Me.udf.UseVisualStyleBackColor = True
        '
        'uds
        '
        Me.uds.Location = New System.Drawing.Point(12, 374)
        Me.uds.Name = "uds"
        Me.uds.Size = New System.Drawing.Size(161, 73)
        Me.uds.TabIndex = 4
        Me.uds.Text = "User defined subroutines"
        Me.uds.UseVisualStyleBackColor = True
        '
        'dbg
        '
        Me.dbg.Location = New System.Drawing.Point(491, 374)
        Me.dbg.Name = "dbg"
        Me.dbg.Size = New System.Drawing.Size(161, 73)
        Me.dbg.TabIndex = 5
        Me.dbg.Text = "Debugging"
        Me.dbg.UseVisualStyleBackColor = True
        '
        'extbtn
        '
        Me.extbtn.BackColor = System.Drawing.Color.Red
        Me.extbtn.Location = New System.Drawing.Point(285, 400)
        Me.extbtn.Name = "extbtn"
        Me.extbtn.Size = New System.Drawing.Size(108, 47)
        Me.extbtn.TabIndex = 7
        Me.extbtn.Text = "Click to Exit"
        Me.extbtn.UseVisualStyleBackColor = False
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(664, 459)
        Me.Controls.Add(Me.extbtn)
        Me.Controls.Add(Me.dbg)
        Me.Controls.Add(Me.uds)
        Me.Controls.Add(Me.udf)
        Me.Controls.Add(Me.pploop)
        Me.Controls.Add(Me.andbtn)
        Me.Controls.Add(Me.welcome)
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents welcome As System.Windows.Forms.Label
    Friend WithEvents andbtn As System.Windows.Forms.Button
    Friend WithEvents pploop As System.Windows.Forms.Button
    Friend WithEvents udf As System.Windows.Forms.Button
    Friend WithEvents uds As System.Windows.Forms.Button
    Friend WithEvents dbg As System.Windows.Forms.Button
    Friend WithEvents extbtn As System.Windows.Forms.Button
End Class
