﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.listv = New System.Windows.Forms.ListView()
        Me.click = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.text1 = New System.Windows.Forms.TextBox()
        Me.gb = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'listv
        '
        Me.listv.Location = New System.Drawing.Point(12, 235)
        Me.listv.Name = "listv"
        Me.listv.Size = New System.Drawing.Size(274, 286)
        Me.listv.TabIndex = 7
        Me.listv.UseCompatibleStateImageBehavior = False
        '
        'click
        '
        Me.click.Location = New System.Drawing.Point(93, 190)
        Me.click.Name = "click"
        Me.click.Size = New System.Drawing.Size(128, 39)
        Me.click.TabIndex = 6
        Me.click.Text = "Display Multiples"
        Me.click.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(30, 86)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(256, 70)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Enter any value to see the first hundred multiples of that value. Subroutines are" & _
    " used here."
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'text1
        '
        Me.text1.Location = New System.Drawing.Point(60, 40)
        Me.text1.Name = "text1"
        Me.text1.Size = New System.Drawing.Size(189, 20)
        Me.text1.TabIndex = 4
        Me.text1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'gb
        '
        Me.gb.BackColor = System.Drawing.SystemColors.Highlight
        Me.gb.Location = New System.Drawing.Point(93, 548)
        Me.gb.Name = "gb"
        Me.gb.Size = New System.Drawing.Size(128, 39)
        Me.gb.TabIndex = 8
        Me.gb.Text = "Go back"
        Me.gb.UseVisualStyleBackColor = False
        '
        'Form4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(298, 599)
        Me.Controls.Add(Me.gb)
        Me.Controls.Add(Me.listv)
        Me.Controls.Add(Me.click)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.text1)
        Me.Name = "Form4"
        Me.Text = "Form4"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents listv As System.Windows.Forms.ListView
    Friend WithEvents click As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents text1 As System.Windows.Forms.TextBox
    Friend WithEvents gb As System.Windows.Forms.Button
End Class
