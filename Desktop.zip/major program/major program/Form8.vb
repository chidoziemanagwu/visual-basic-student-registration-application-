﻿Public Class Form8

    Private Sub gb_Click(sender As Object, e As EventArgs) Handles gb.Click
        Me.Hide()
        Form2.Show()

    End Sub
    Private Sub mult_Click(sender As Object, e As EventArgs) Handles mult.Click
        Dim sum, n As Integer
        n = Val(valuebox.Text)
        Do
            n += 1
            sum += n
            listv.Items.Add(n & vbTab & sum)
            If n = 30 Then
                Exit Do
            End If
        Loop While n <= 100



    End Sub
End Class