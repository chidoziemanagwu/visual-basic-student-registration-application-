﻿Imports System.Data.OleDb
Public Class Form1
    Dim provider As String
    Dim datafile As String
    Dim connstring As String
    Dim myconnection As OleDbConnection = New OleDbConnection
    Dim providerr As String
    Dim datafiler As String
    Dim connstringr As String
    Dim myconnectionr As OleDbConnection = New OleDbConnection

    Private Sub signup_Click(sender As Object, e As EventArgs) Handles signup.Click
        provider = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source ="
        datafile = "C:\Users\hp pc\Documents\Visual Studio 2013\Projects\major program\major program\Studentdb.accdb"
        connstring = provider & datafile
        myconnection.ConnectionString = connstring

        myconnection.Open()
        Dim str As String
        str = "insert into studenttable([studentFirstName], [studentLastName], [vbLabName], [shortDescription], [datestarted], [targetdate], [username], [password]) values (?, ?, ?, ?, ?, ?, ?, ?)"
        Dim cmd As OleDbCommand = New OleDbCommand(str, myconnection)
        cmd.Parameters.Add(New OleDbParameter("studentFirstName", CType(sfname.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("studentLastName", CType(slname.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("vbLabName", CType(labname.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("shortDescription", CType(sdesc.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("datestarted", CType(started.Value.Date, Date)))
        cmd.Parameters.Add(New OleDbParameter("targetdate", CType(target.Value.Date, Date)))
        cmd.Parameters.Add(New OleDbParameter("username", CType(uname1.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("password", CType(pword1.Text, String)))
        Try
            cmd.ExecuteNonQuery()
            cmd.Dispose()

            MsgBox("Sign Up Successful, Welcome " & sfname.Text, MessageBoxIcon.Information, "Sign Up Form")
            sfname.Clear()
            slname.Clear()
            labname.Clear()
            sdesc.Clear()
            uname1.Clear()
            pword1.Clear()
            Me.Hide()
            Form2.Show()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub signin_Click(sender As Object, e As EventArgs) Handles signin.Click
        providerr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source ="
        datafiler = "C:\Users\hp pc\Documents\Visual Studio 2013\Projects\major program\major program\Studentdb.accdb"
        connstringr = providerr & datafiler
        myconnectionr.ConnectionString = connstringr

        myconnectionr.Open()
        Dim cmdr As OleDbCommand = New OleDbCommand("SELECT * FROM [studenttable] WHERE [username] = '" & uname.Text & "' AND [password] = '" & pword.Text & "'", myconnectionr)
        Dim dr As OleDbDataReader = cmdr.ExecuteReader
        Dim userfound As Boolean = False
        Dim firstname As String = ""
        Dim lastname As String = ""

        While dr.Read
            userfound = True
            firstname = dr("studentFirstName").ToString
            lastname = dr("studentLastName").ToString
        End While
        If userfound = True Then
            If uname.Text = "admin" And pword.Text = "admin123" Then
                Me.Hide()
                uname.Clear()
                pword.Clear()
                MsgBox("Welcome " & firstname & " " & lastname)
                Form3.Show()

            Else
                Me.Hide()
                uname.Clear()
                pword.Clear()

                MsgBox("Welcome " & firstname & " " & lastname)
                Form2.Show()
            End If
        Else

            MsgBox("Sorry,username or password is incorrect", MessageBoxIcon.Error, "Sign In")
           
        End If
    End Sub

    Private Sub showp1_Click(sender As Object, e As EventArgs) Handles showp1.Click
        pword.PasswordChar = ""
        hidep1.Visible = True
        showp1.Visible = False
    End Sub

    Private Sub hidep1_Click(sender As Object, e As EventArgs) Handles hidep1.Click
        pword.PasswordChar = "*"
        hidep1.Visible = False
        showp1.Visible = True
    End Sub

    
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        hidep.Visible = False
        hidep1.Visible = False
    End Sub

    Private Sub showp_Click(sender As Object, e As EventArgs) Handles showp.Click
        pword1.PasswordChar = ""
        hidep.Visible = True
        showp.Visible = False
    End Sub

    Private Sub hidep_Click(sender As Object, e As EventArgs) Handles hidep.Click
        pword1.PasswordChar = "*"
        hidep.Visible = False
        showp.Visible = True
    End Sub
End Class
