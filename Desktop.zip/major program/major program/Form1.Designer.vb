﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.hidep1 = New System.Windows.Forms.Button()
        Me.showp1 = New System.Windows.Forms.Button()
        Me.signin = New System.Windows.Forms.Button()
        Me.pword = New System.Windows.Forms.TextBox()
        Me.uname = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.showp = New System.Windows.Forms.Button()
        Me.hidep = New System.Windows.Forms.Button()
        Me.target = New System.Windows.Forms.DateTimePicker()
        Me.started = New System.Windows.Forms.DateTimePicker()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.signup = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.pword1 = New System.Windows.Forms.TextBox()
        Me.uname1 = New System.Windows.Forms.TextBox()
        Me.sdesc = New System.Windows.Forms.TextBox()
        Me.labname = New System.Windows.Forms.TextBox()
        Me.slname = New System.Windows.Forms.TextBox()
        Me.sfname = New System.Windows.Forms.TextBox()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(12, 12)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(629, 638)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.Silver
        Me.TabPage1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.TabPage1.Controls.Add(Me.hidep1)
        Me.TabPage1.Controls.Add(Me.showp1)
        Me.TabPage1.Controls.Add(Me.signin)
        Me.TabPage1.Controls.Add(Me.pword)
        Me.TabPage1.Controls.Add(Me.uname)
        Me.TabPage1.Controls.Add(Me.Label11)
        Me.TabPage1.Controls.Add(Me.Label10)
        Me.TabPage1.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(621, 612)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "SIGN IN"
        '
        'hidep1
        '
        Me.hidep1.BackColor = System.Drawing.Color.PaleGreen
        Me.hidep1.Location = New System.Drawing.Point(434, 380)
        Me.hidep1.Name = "hidep1"
        Me.hidep1.Size = New System.Drawing.Size(155, 51)
        Me.hidep1.TabIndex = 6
        Me.hidep1.Text = "Hide Password"
        Me.hidep1.UseVisualStyleBackColor = False
        '
        'showp1
        '
        Me.showp1.BackColor = System.Drawing.Color.PaleGreen
        Me.showp1.Location = New System.Drawing.Point(56, 380)
        Me.showp1.Name = "showp1"
        Me.showp1.Size = New System.Drawing.Size(155, 51)
        Me.showp1.TabIndex = 5
        Me.showp1.Text = "Show Password"
        Me.showp1.UseVisualStyleBackColor = False
        '
        'signin
        '
        Me.signin.BackColor = System.Drawing.Color.PaleGreen
        Me.signin.Location = New System.Drawing.Point(248, 380)
        Me.signin.Name = "signin"
        Me.signin.Size = New System.Drawing.Size(155, 51)
        Me.signin.TabIndex = 4
        Me.signin.Text = "Sign In"
        Me.signin.UseVisualStyleBackColor = False
        '
        'pword
        '
        Me.pword.Location = New System.Drawing.Point(330, 256)
        Me.pword.Name = "pword"
        Me.pword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.pword.Size = New System.Drawing.Size(149, 23)
        Me.pword.TabIndex = 3
        '
        'uname
        '
        Me.uname.Location = New System.Drawing.Point(330, 94)
        Me.uname.Name = "uname"
        Me.uname.Size = New System.Drawing.Size(149, 23)
        Me.uname.TabIndex = 2
        '
        'Label11
        '
        Me.Label11.Location = New System.Drawing.Point(163, 256)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(128, 26)
        Me.Label11.TabIndex = 1
        Me.Label11.Text = "Password"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(150, 96)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(157, 31)
        Me.Label10.TabIndex = 0
        Me.Label10.Text = "Username"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.Silver
        Me.TabPage2.Controls.Add(Me.showp)
        Me.TabPage2.Controls.Add(Me.hidep)
        Me.TabPage2.Controls.Add(Me.target)
        Me.TabPage2.Controls.Add(Me.started)
        Me.TabPage2.Controls.Add(Me.Label9)
        Me.TabPage2.Controls.Add(Me.Label8)
        Me.TabPage2.Controls.Add(Me.signup)
        Me.TabPage2.Controls.Add(Me.Label7)
        Me.TabPage2.Controls.Add(Me.Label6)
        Me.TabPage2.Controls.Add(Me.Label5)
        Me.TabPage2.Controls.Add(Me.Label4)
        Me.TabPage2.Controls.Add(Me.Label3)
        Me.TabPage2.Controls.Add(Me.Label2)
        Me.TabPage2.Controls.Add(Me.Label1)
        Me.TabPage2.Controls.Add(Me.pword1)
        Me.TabPage2.Controls.Add(Me.uname1)
        Me.TabPage2.Controls.Add(Me.sdesc)
        Me.TabPage2.Controls.Add(Me.labname)
        Me.TabPage2.Controls.Add(Me.slname)
        Me.TabPage2.Controls.Add(Me.sfname)
        Me.TabPage2.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(621, 612)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "SIGN UP"
        '
        'showp
        '
        Me.showp.BackColor = System.Drawing.Color.PaleGreen
        Me.showp.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.showp.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.showp.Location = New System.Drawing.Point(66, 556)
        Me.showp.Name = "showp"
        Me.showp.Size = New System.Drawing.Size(139, 35)
        Me.showp.TabIndex = 19
        Me.showp.Text = "Show Password"
        Me.showp.UseVisualStyleBackColor = False
        '
        'hidep
        '
        Me.hidep.BackColor = System.Drawing.Color.PaleGreen
        Me.hidep.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.hidep.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hidep.Location = New System.Drawing.Point(419, 556)
        Me.hidep.Name = "hidep"
        Me.hidep.Size = New System.Drawing.Size(139, 35)
        Me.hidep.TabIndex = 18
        Me.hidep.Text = "Hide Password"
        Me.hidep.UseVisualStyleBackColor = False
        '
        'target
        '
        Me.target.Location = New System.Drawing.Point(322, 339)
        Me.target.Name = "target"
        Me.target.Size = New System.Drawing.Size(200, 23)
        Me.target.TabIndex = 17
        '
        'started
        '
        Me.started.Location = New System.Drawing.Point(30, 339)
        Me.started.Name = "started"
        Me.started.Size = New System.Drawing.Size(200, 23)
        Me.started.TabIndex = 16
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(82, 323)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(77, 15)
        Me.Label9.TabIndex = 15
        Me.Label9.Text = "Date Started"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(360, 323)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(134, 15)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "Target completion date"
        '
        'signup
        '
        Me.signup.BackColor = System.Drawing.Color.PaleGreen
        Me.signup.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.signup.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.signup.Location = New System.Drawing.Point(241, 556)
        Me.signup.Name = "signup"
        Me.signup.Size = New System.Drawing.Size(139, 35)
        Me.signup.TabIndex = 13
        Me.signup.Text = "Sign Up"
        Me.signup.UseVisualStyleBackColor = False
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Coral
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label7.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Label7.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(45, 397)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(513, 57)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "USER LOGIN DETAILS"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(444, 526)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(59, 15)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Password"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(94, 526)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(63, 15)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Username"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(63, 220)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(101, 15)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Short description"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(63, 164)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(120, 15)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Vb lab/project name"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(63, 104)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(112, 15)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Student Last Name"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(63, 48)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(114, 15)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Student First Name"
        '
        'pword1
        '
        Me.pword1.Location = New System.Drawing.Point(387, 490)
        Me.pword1.MaxLength = 10
        Me.pword1.Name = "pword1"
        Me.pword1.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.pword1.Size = New System.Drawing.Size(171, 23)
        Me.pword1.TabIndex = 5
        '
        'uname1
        '
        Me.uname1.Location = New System.Drawing.Point(45, 490)
        Me.uname1.MaxLength = 30
        Me.uname1.Name = "uname1"
        Me.uname1.Size = New System.Drawing.Size(171, 23)
        Me.uname1.TabIndex = 4
        '
        'sdesc
        '
        Me.sdesc.Location = New System.Drawing.Point(305, 217)
        Me.sdesc.MaxLength = 60
        Me.sdesc.Multiline = True
        Me.sdesc.Name = "sdesc"
        Me.sdesc.Size = New System.Drawing.Size(171, 85)
        Me.sdesc.TabIndex = 3
        '
        'labname
        '
        Me.labname.Location = New System.Drawing.Point(305, 157)
        Me.labname.MaxLength = 50
        Me.labname.Name = "labname"
        Me.labname.Size = New System.Drawing.Size(171, 23)
        Me.labname.TabIndex = 2
        '
        'slname
        '
        Me.slname.Location = New System.Drawing.Point(305, 97)
        Me.slname.MaxLength = 40
        Me.slname.Name = "slname"
        Me.slname.Size = New System.Drawing.Size(171, 23)
        Me.slname.TabIndex = 1
        '
        'sfname
        '
        Me.sfname.Location = New System.Drawing.Point(305, 40)
        Me.sfname.MaxLength = 30
        Me.sfname.Name = "sfname"
        Me.sfname.Size = New System.Drawing.Size(171, 23)
        Me.sfname.TabIndex = 0
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(653, 662)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents signup As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents pword1 As System.Windows.Forms.TextBox
    Friend WithEvents uname1 As System.Windows.Forms.TextBox
    Friend WithEvents sdesc As System.Windows.Forms.TextBox
    Friend WithEvents labname As System.Windows.Forms.TextBox
    Friend WithEvents slname As System.Windows.Forms.TextBox
    Friend WithEvents sfname As System.Windows.Forms.TextBox
    Friend WithEvents target As System.Windows.Forms.DateTimePicker
    Friend WithEvents started As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents signin As System.Windows.Forms.Button
    Friend WithEvents pword As System.Windows.Forms.TextBox
    Friend WithEvents uname As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents hidep1 As System.Windows.Forms.Button
    Friend WithEvents showp1 As System.Windows.Forms.Button
    Friend WithEvents showp As System.Windows.Forms.Button
    Friend WithEvents hidep As System.Windows.Forms.Button

End Class
