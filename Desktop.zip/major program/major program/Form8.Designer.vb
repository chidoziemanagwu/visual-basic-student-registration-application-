﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form8
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.listv = New System.Windows.Forms.ListBox()
        Me.valuebox = New System.Windows.Forms.TextBox()
        Me.mult = New System.Windows.Forms.Button()
        Me.gb = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(328, 57)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(175, 13)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Enter a value in the tex box abovve"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(306, 146)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(220, 151)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "This program makes use of post and pre conditions to increment the value you ente" & _
    "r by itself after every iteration, it exits itself once it has iterated 30 times" & _
    "."
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'listv
        '
        Me.listv.FormattingEnabled = True
        Me.listv.Location = New System.Drawing.Point(45, 8)
        Me.listv.Name = "listv"
        Me.listv.Size = New System.Drawing.Size(213, 290)
        Me.listv.TabIndex = 8
        '
        'valuebox
        '
        Me.valuebox.Location = New System.Drawing.Point(343, 22)
        Me.valuebox.Name = "valuebox"
        Me.valuebox.Size = New System.Drawing.Size(144, 20)
        Me.valuebox.TabIndex = 7
        Me.valuebox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'mult
        '
        Me.mult.Location = New System.Drawing.Point(343, 88)
        Me.mult.Name = "mult"
        Me.mult.Size = New System.Drawing.Size(144, 35)
        Me.mult.TabIndex = 6
        Me.mult.Text = "Increment"
        Me.mult.UseVisualStyleBackColor = True
        '
        'gb
        '
        Me.gb.Location = New System.Drawing.Point(139, 313)
        Me.gb.Name = "gb"
        Me.gb.Size = New System.Drawing.Size(290, 35)
        Me.gb.TabIndex = 11
        Me.gb.Text = "Go Back"
        Me.gb.UseVisualStyleBackColor = True
        '
        'Form8
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(571, 360)
        Me.Controls.Add(Me.gb)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.listv)
        Me.Controls.Add(Me.valuebox)
        Me.Controls.Add(Me.mult)
        Me.Name = "Form8"
        Me.Text = "Form8"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents listv As System.Windows.Forms.ListBox
    Friend WithEvents valuebox As System.Windows.Forms.TextBox
    Friend WithEvents mult As System.Windows.Forms.Button
    Friend WithEvents gb As System.Windows.Forms.Button
End Class
